import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminSpots = () => {
  const [spots, setSpots] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    axios.get('http://127.0.0.1:8000/api/parking/spots/', {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(response => {
      setSpots(response.data);
    })
    .catch(error => {
      console.error('Error fetching spots:', error);
    });
  }, []);

  return (
    <div>
      <h2>Керування паркувальними зонами</h2>
      <ul>
        {spots.map(spot => (
          <li key={spot.id}>
            {spot.location} (Lat: {spot.latitude}, Lng: {spot.longitude})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminSpots;
