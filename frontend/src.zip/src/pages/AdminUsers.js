import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminUsers = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    axios.get('http://127.0.0.1:8000/api/auth/users/', {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(response => {
      setUsers(response.data);
    })
    .catch(error => {
      console.error('Error fetching users:', error);
    });
  }, []);

  return (
    <div>
      <h2>Керування користувачами</h2>
      <ul>
        {users.map(user => (
          <li key={user.id}>
            {user.username} ({user.email}) {user.is_superuser ? "(Admin)" : ""}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminUsers;
